import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function PartyChaosWebsite() {
  return (
    <div className="min-h-screen bg-white text-gray-800 overflow-hidden">
      <section className="relative overflow-hidden bg-gradient-to-r from-purple-700 via-fuchsia-600 to-pink-500 text-white py-24 px-6">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ y: [0, -15, 0], x: [0, 15, 0], rotate: [0, 360, 0] }}
            transition={{ repeat: Infinity, duration: 5 + Math.random() * 3 }}
            style={{
              position: "absolute",
              width: `${10 + i * 3}px`,
              height: `${10 + i * 3}px`,
              borderRadius: "50%",
              backgroundColor: `hsla(${Math.random() * 360}, 70%, 60%, 0.35)`,
              top: `${Math.random() * 90}%`,
              left: `${Math.random() * 90}%`
            }}
          />
        ))}

        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="relative max-w-6xl mx-auto text-center">
          <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.8 }} className="mb-10">
            <h2 className="text-7xl md:text-8xl font-black tracking-widest text-yellow-300 drop-shadow-[0_0_30px_rgba(253,224,71,0.95)] animate-pulse">
              COMING SOON
            </h2>
            <p className="mt-4 text-xl md:text-2xl font-bold text-white/90">
              Texas’ most exciting new party destination
            </p>
          </motion.div>

          <h1 className="text-6xl font-extrabold mb-4 drop-shadow-lg">
            <span className="text-cyan-300">Party</span> Chaos
          </h1>

          <p className="text-xl mb-4 font-semibold">NEW PARTY STORE</p>

          <p className="text-lg mb-6 font-bold">
            <span className="text-yellow-300">Balloons</span> • 
            <span className="text-cyan-300"> Party Supplies</span> • 
            <span className="text-pink-300"> More</span>
          </p>

          <p className="text-md mb-8">
            110 N I 35 Frontage Rd, Suite 296<br />
            Round Rock, TX 78681
          </p>

          <Button className="bg-yellow-300 text-purple-800 font-bold px-10 py-4 rounded-2xl shadow-lg">
            Grand Opening Soon
          </Button>
        </motion.div>
      </section>

      <section className="py-20 px-6 bg-gradient-to-br from-yellow-50 via-pink-50 to-cyan-50">
        <h2 className="text-4xl font-extrabold text-center mb-12 text-purple-700">Our Services</h2>
      </section>

      <footer className="bg-black text-white py-6 text-center">
        <p>© {new Date().getFullYear()} Party Chaos. All rights reserved.</p>
      </footer>
    </div>
  );
}
